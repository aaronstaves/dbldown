package t::mod::a;
use t::mod::b;

$foo = "bar";

1;
