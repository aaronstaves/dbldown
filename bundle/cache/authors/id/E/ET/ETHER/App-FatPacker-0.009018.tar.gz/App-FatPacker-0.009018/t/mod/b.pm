package t::mod::b;
use t::mod::c;
1;
