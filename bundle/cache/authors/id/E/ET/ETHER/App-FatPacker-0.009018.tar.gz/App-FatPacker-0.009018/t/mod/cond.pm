package t::mod::cond;
eval { require t::mod::nothere };
1;
