use strictures;

package sub_class;

use Moo;

extends 'base_class';
