use strictures;

package base_class;
use Moo;
extends "marp";

1;
